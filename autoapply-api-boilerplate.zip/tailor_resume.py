import openai
openai.api_key = "YOUR_API_KEY"

def generate_tailored_resume(resume_text, job_description):
    prompt = f"""You are an expert resume editor. Tailor the resume below to fit the job description.

Resume:
{resume_text}

Job Description:
{job_description}

Please rewrite the resume to better match the job description, emphasizing relevant skills and experience.
"""
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "system", "content": "You are a resume optimization assistant."},
                  {"role": "user", "content": prompt}],
        temperature=0.7
    )
    return response.choices[0].message.content
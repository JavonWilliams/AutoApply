from fastapi import FastAPI, UploadFile, Form
from resume_processor import extract_text
from tailor_resume import generate_tailored_resume
from pdf_generator import create_pdf
from fastapi.responses import FileResponse

app = FastAPI()

@app.post("/upload-resume/")
async def upload_resume(file: UploadFile):
    text = await extract_text(file)
    return {"resume_text": text}

@app.post("/tailor-resume/")
async def tailor(resume_text: str = Form(...), job_description: str = Form(...)):
    tailored = generate_tailored_resume(resume_text, job_description)
    return {"tailored_resume": tailored}

@app.post("/generate-pdf/")
async def generate_pdf(content: str = Form(...)):
    file_path = create_pdf(content)
    return FileResponse(file_path, filename="Tailored_Resume.pdf")
from PyPDF2 import PdfReader
import docx

async def extract_text(file):
    if file.filename.endswith('.pdf'):
        reader = PdfReader(file.file)
        return "\n".join([p.extract_text() for p in reader.pages])
    elif file.filename.endswith('.docx'):
        doc = docx.Document(file.file)
        return "\n".join([p.text for p in doc.paragraphs])
    else:
        return "Unsupported file format"
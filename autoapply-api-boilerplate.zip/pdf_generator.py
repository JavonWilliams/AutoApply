from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

def create_pdf(content, file_path="tailored_resume.pdf"):
    c = canvas.Canvas(file_path, pagesize=letter)
    y = 750
    for line in content.split("\n"):
        c.drawString(40, y, line.strip())
        y -= 15
    c.save()
    return file_path